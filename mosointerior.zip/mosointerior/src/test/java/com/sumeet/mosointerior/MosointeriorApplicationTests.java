package com.sumeet.mosointerior;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MosointeriorApplicationTests {

	@Test
	void contextLoads() {
	}

}
