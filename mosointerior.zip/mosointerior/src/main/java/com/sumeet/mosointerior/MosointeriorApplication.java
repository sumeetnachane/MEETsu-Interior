package com.sumeet.mosointerior;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MosointeriorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MosointeriorApplication.class, args);
		System.out.println("Interior...");
	}

}
