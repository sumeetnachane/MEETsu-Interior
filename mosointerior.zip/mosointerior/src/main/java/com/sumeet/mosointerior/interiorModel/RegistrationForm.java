package com.sumeet.mosointerior.interiorModel;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;


@Entity
public class RegistrationForm {

	private String name;
	private String mobilenumber;
	private String address;
	@Id
	private String aadharcard;
	private String aadharphoto;
	private String profile;
	public RegistrationForm() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RegistrationForm(String name, String mobilenumber, String address, String aadharcard, String aadharphoto,
			String profile) {
		super();
		this.name = name;
		this.mobilenumber = mobilenumber;
		this.address = address;
		this.aadharcard = aadharcard;
		this.aadharphoto = aadharphoto;
		this.profile = profile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAadharcard() {
		return aadharcard;
	}
	public void setAadharcard(String aadharcard) {
		this.aadharcard = aadharcard;
	}
	public String getAadharphoto() {
		return aadharphoto;
	}
	public void setAadharphoto(String aadharphoto) {
		this.aadharphoto = aadharphoto;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	@Override
	public String toString() {
		return "RegistrationForm [name=" + name + ", mobilenumber=" + mobilenumber + ", address=" + address
				+ ", aadharcard=" + aadharcard + ", aadharphoto=" + aadharphoto + ", profile=" + profile + "]";
	}
	
	
}
