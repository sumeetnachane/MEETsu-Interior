package com.sumeet.mosointerior.interiorController;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sumeet.mosointerior.interiorModel.Contact;
import com.sumeet.mosointerior.interiorModel.Login;
import com.sumeet.mosointerior.interiorModel.RegistrationForm;

@Controller
public class InteriorController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("homepage")
	public String homePage() {
		return "index";
		
	}
	
	
	@RequestMapping("aboutpage")
	public String aboutPage() {
		return "index";
		
	}
	
	
	@RequestMapping("shopepage")
	public String shopePage() {
		return "index";
		
	}
	
	
	@RequestMapping("shopelisting")
	public String shopeListing() {
		return "shoplisting";
		
	}
	
	@RequestMapping("shopedetail")
	public String shopeDetails() {
		return "shopdetail";
		
	}
	
	
	@RequestMapping("reviewspage")
	public String reviewsPage() {
		return "index";
		
	}
	
	
	@RequestMapping("contactpage")
	public String contactPage() {
		return "index";
		
	}
	
	@RequestMapping("contactsavepage")
	public String contactSave(Contact contact) {

		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(contact);
		tt.commit();
		return "index";

	}
	
	@RequestMapping("userloginpage")
	public String loginPage() {
		return "login";
		
	}
	
	@RequestMapping("userloginhome")
	public String loginSave(Login login) {
		
		Session SS = sf.openSession();
		Login dbLogin = SS.get(Login.class, login.getPassword());
		
		if (dbLogin !=null) {
			if (dbLogin.equals(dbLogin)) {
				return "index";
			} else {
				return "userlogin";
			}
		}
		return "userlogin";
	}
	
	
	@RequestMapping("createaccountpage")
	public String createAccountPage() {
		return "createaccount";
		
	}
	
	@RequestMapping("createaccountsave")
	public String createAccountSave(Login login) {
		
		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(login);
		tt.commit();
		return "createaccount";
		
	}
	
	@RequestMapping("registrationformpage")
	public String registrationform() {
		return "registrationform";
		
	}
	@RequestMapping("registrationformsave")
	public String registratinformSave(RegistrationForm form) {
		
		Session ss = sf.openSession();
		Transaction tt = ss.beginTransaction();
		ss.persist(form);
		tt.commit();
		return "registrationform";
		
	}
}
